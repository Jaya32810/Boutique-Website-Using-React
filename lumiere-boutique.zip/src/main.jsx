import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const products = [
  {id:1,name:"Blush Pink Saree",cat:"Sarees",price:2499,img:"https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=700&q=80"},
  {id:2,name:"Pastel Party Dress",cat:"Dresses",price:1899,img:"https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=700&q=80"},
  {id:3,name:"Lavender Kurti",cat:"Kurtis",price:999,img:"https://images.unsplash.com/photo-1583391733956-6c78276477e2?auto=format&fit=crop&w=700&q=80"},
  {id:4,name:"Elegant Evening Gown",cat:"Gowns",price:2999,img:"https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=700&q=80"},
  {id:5,name:"Peach Floral Dress",cat:"Dresses",price:1599,img:"https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=700&q=80"},
  {id:6,name:"Cream Designer Saree",cat:"Sarees",price:2799,img:"https://images.unsplash.com/photo-1610189012906-4b3f0f4f9d7b?auto=format&fit=crop&w=700&q=80"}
];

function App(){
  const [cat,setCat]=useState("All");
  const [search,setSearch]=useState("");
  const [cart,setCart]=useState([]);
  const [wish,setWish]=useState([]);

  const filtered=products.filter(p=>
    (cat==="All"||p.cat===cat) && p.name.toLowerCase().includes(search.toLowerCase())
  );
  const total=cart.reduce((s,p)=>s+p.price,0);

  const add=p=>setCart(c=>[...c,p]);
  const toggleWish=id=>setWish(w=>w.includes(id)?w.filter(x=>x!==id):[...w,id]);

  return <div>
    <header className="nav">
      <div className="logo">LUMIÈRE<span>.</span></div>
      <nav>
        <a href="#home">Home</a><a href="#shop">Shop</a><a href="#categories">Categories</a>
        <a href="#about">About</a><a href="#contact">Contact</a>
      </nav>
      <div className="actions">
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search..." />
        <button className="cart">🛒 {cart.length}</button>
        <span className="wish">♡ {wish.length}</span>
      </div>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="heroText">
          <small>NEW COLLECTION 2026</small>
          <h1>Elegance<br/>in Every <i>Detail.</i></h1>
          <p>Discover timeless fashion designed to make every moment beautifully yours.</p>
          <a className="primary" href="#shop">SHOP COLLECTION →</a>
        </div>
        <img src="https://images.unsplash.com/photo-1496217590455-aa63a8350eea?auto=format&fit=crop&w=1000&q=80" alt="Fashion"/>
      </section>

      <section className="section" id="categories">
        <div className="heading"><small>EXPLORE</small><h2>Shop by Category</h2></div>
        <div className="categories">
          {[["🥻","Sarees","Elegant & Traditional"],["👗","Dresses","Chic & Beautiful"],["👚","Kurtis","Comfort & Style"],["✨","Gowns","Perfect for Parties"]].map(x=>
            <button key={x[1]} onClick={()=>setCat(x[1])}><b>{x[0]}</b><h3>{x[1]}</h3><p>{x[2]}</p></button>
          )}
        </div>
      </section>

      <section className="section shop" id="shop">
        <div className="shopHead"><div><small>OUR COLLECTION</small><h2>Trending Pieces</h2></div><button onClick={()=>setCat("All")}>VIEW ALL</button></div>
        <div className="products">
          {filtered.map(p=><article className="card" key={p.id}>
            <div className="photo"><img src={p.img} alt={p.name}/><button className="heart" onClick={()=>toggleWish(p.id)}>{wish.includes(p.id)?"♥":"♡"}</button></div>
            <div className="info"><small>{p.cat}</small><h3>{p.name}</h3><div className="bottom"><strong>₹{p.price}</strong><button onClick={()=>add(p)}>+ Add</button></div></div>
          </article>)}
        </div>
        {!filtered.length && <div className="empty">No products found 🌸</div>}
      </section>

      <section className="about" id="about">
        <img src="https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1000&q=80" alt="Boutique"/>
        <div><small>OUR STORY</small><h2>Fashion that feels<br/><i>like you.</i></h2>
        <p>At Lumière Boutique, we believe fashion is more than clothing. It is a beautiful way to express who you are.</p>
        <p>From elegant sarees to modern dresses, every piece is selected with love, style and individuality in mind.</p>
        <button className="primary">LEARN MORE →</button></div>
      </section>

      <section className="newsletter">
        <small>JOIN OUR WORLD</small><h2>Stay in the loop ✨</h2><p>Get updates about new collections and exclusive offers.</p>
        <div><input placeholder="Enter your email"/><button>SUBSCRIBE</button></div>
      </section>

      <section className="contact" id="contact">
        <div><small>GET IN TOUCH</small><h2>Let's talk fashion.</h2></div>
        <div><p>📍 Kadapa, Andhra Pradesh</p><p>📞 +91 98765 43210</p><p>✉️ hello@lumiereboutique.com</p></div>
      </section>

      {cart.length>0 && <aside className="cartPanel">
        <h3>Your Cart 🛍️</h3>{cart.map((p,i)=><div key={i}><span>{p.name}</span><b>₹{p.price}</b></div>)}
        <hr/><strong>Total: ₹{total}</strong>
      </aside>}
    </main>

    <footer><div className="logo">LUMIÈRE<span>.</span></div><p>© 2026 Lumière Boutique. Made with ♡</p><p>Instagram • Facebook • Pinterest</p></footer>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);